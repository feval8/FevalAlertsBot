# FevalAlertsBot - Versión Final COMPLETA + EXTENDIDA
# Este archivo ha sido adaptado para ser desplegado en Railway, usando variables de entorno

import logging
import asyncio
import datetime
import random
import requests
import os
import nest_asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, ContextTypes, CommandHandler, CallbackQueryHandler
)
from apscheduler.schedulers.asyncio import AsyncIOScheduler

# Configura logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Variables globales
user_risk_levels = {}
user_alerts = {}
user_chats = set()
seguimiento = ["FIL", "TON", "FET", "TAO", "TRX"]
cartera_real = {
    "SOLX": 187.252,
    "TICS": 592.58,
    "BTC": 0.0024,
    "NVDA": 2.46,
    "AMZN": 1.01,
    "META": 0.28
}

def obtener_precios():
    precios = {}
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,filecoin,toncoin,fetch-ai,bittensor,tron&vs_currencies=usd")
        if r.status_code == 200:
            data = r.json()
            precios.update({
                "BTC": data.get("bitcoin", {}).get("usd", 0),
                "FIL": data.get("filecoin", {}).get("usd", 0),
                "TON": data.get("toncoin", {}).get("usd", 0),
                "FET": data.get("fetch-ai", {}).get("usd", 0),
                "TAO": data.get("bittensor", {}).get("usd", 0),
                "TRX": data.get("tron", {}).get("usd", 0)
            })
    except Exception as e:
        print("Error CoinGecko:", e)

    precios["SOLX"] = 0.11  # Simulación
    precios["TICS"] = 0.27  # Simulación
    precios["NVDA"] = 130
    precios["AMZN"] = 185
    precios["META"] = 482

    return precios

async def enviar_informe_horario():
    try:
        precios = obtener_precios()
        for chat_id in user_chats:
            texto = "⏰ *Informe horario:*
"
            for token, cantidad in cartera_real.items():
                precio = precios.get(token, 0)
                total = round(cantidad * precio, 2)
                texto += f"• {token}: {total} $
"
            recomendaciones = []
            for token in seguimiento:
                precio = precios.get(token, 0)
                if precio > 0 and random.random() > 0.85:
                    recomendaciones.append(f"✨ Entrada potencial detectada en {token} ({precio}$)")
            if recomendaciones:
                texto += "
" + "
".join(recomendaciones)
            await app.bot.send_message(chat_id=chat_id, text=texto, parse_mode="Markdown")
    except Exception as e:
        print("Error informe horario:", e)

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data.startswith("desactivar_"):
        token = query.data.split("_")[1]
        user_id = query.from_user.id
        if user_id in user_alerts and token in user_alerts[user_id]:
            del user_alerts[user_id][token]
            await query.edit_message_text(f"✅ Alerta desactivada para {token}.")
        else:
            await query.edit_message_text("No hay alerta activa para ese token.")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_chats.add(update.effective_chat.id)
    texto = (
        "✅ Bot activado. Tu chat ha sido registrado para recibir alertas.
"
        "📋 Comandos disponibles:
"
        "/estado - Ver tu cartera actual
"
        "/analiza TOKEN - Análisis técnico
"
        "/resumen - Informe general
"
        "/set_riesgo - Elegir nivel de riesgo
"
        "/alertas - Ver alertas activas
"
        "/modificar_alerta - Ajustar alertas
"
        "/ayuda - Ver todo el menú con botones"
    )
    keyboard = [[InlineKeyboardButton("Ver menú completo", callback_data="ayuda")]]
    await update.message.reply_text(texto, reply_markup=InlineKeyboardMarkup(keyboard))

async def estado(update: Update, context: ContextTypes.DEFAULT_TYPE):
    precios = obtener_precios()
    texto = "📊 Estado de cartera actual:
"
    total_usd = 0
    for token, cantidad in cartera_real.items():
        precio = precios.get(token, 0)
        total = round(cantidad * precio, 2)
        total_usd += total
        texto += f"• {token}: {cantidad} @ {precio}$ = {total}$
"
    texto += f"
*Total estimado:* {round(total_usd, 2)} $"
    await update.message.reply_text(texto, parse_mode="Markdown")

async def ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    texto = (
        "🛈 *Menú de ayuda:*
"
        "/estado - Estado actual de tu cartera
"
        "/analiza TOKEN - Análisis técnico
"
        "/resumen - Informe general de mercado
"
        "/set_riesgo - Ajusta el nivel de riesgo
"
        "/alertas - Muestra tus alertas activas
"
        "/modificar_alerta - Cambia los niveles de alerta"
    )
    await update.message.reply_text(texto, parse_mode="Markdown")

async def resumen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    precios = obtener_precios()
    texto = "📈 *Resumen del mercado:*
"
    for token in seguimiento:
        precio = precios.get(token, 0)
        texto += f"• {token}: {precio} $
"
    await update.message.reply_text(texto, parse_mode="Markdown")

async def analiza(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        token = context.args[0].upper()
        precio = obtener_precios().get(token, 0)
        if not precio:
            await update.message.reply_text("❌ Token no reconocido o sin precio disponible.")
            return
        sl = round(precio * 0.9, 3)
        tp = round(precio * 1.15, 3)
        probabilidad = random.randint(65, 90)
        texto = f"🔬 *Análisis técnico de {token}*
Precio actual: {precio}$
Probabilidad de éxito: {probabilidad}%
TP (Take Profit): {tp}$
SL (Stop Loss): {sl}$"
        await update.message.reply_text(texto, parse_mode="Markdown")
    except:
        await update.message.reply_text("❌ Uso incorrecto. Escribe `/analiza TOKEN`.", parse_mode="Markdown")

async def set_riesgo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        nivel = context.args[0].lower()
        user_risk_levels[update.effective_user.id] = nivel
        await update.message.reply_text(f"✅ Nivel de riesgo ajustado a: {nivel}")
    except:
        await update.message.reply_text("❌ Escribe `/set_riesgo bajo|medio|alto`.", parse_mode="Markdown")

# Lanzar app con asyncio
nest_asyncio.apply()

async def main():
    global app
    token = os.getenv("BOT_TOKEN")
    app = ApplicationBuilder().token(token).build()

    scheduler = AsyncIOScheduler()
    scheduler.add_job(enviar_informe_horario, 'interval', hours=1)
    scheduler.start()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("estado", estado))
    app.add_handler(CommandHandler("ayuda", ayuda))
    app.add_handler(CommandHandler("resumen", resumen))
    app.add_handler(CommandHandler("analiza", analiza))
    app.add_handler(CommandHandler("set_riesgo", set_riesgo))
    app.add_handler(CallbackQueryHandler(callback_handler))

    print("✅ Bot FevalAlertsBot iniciado correctamente.")
    await app.run_polling()

asyncio.run(main())
